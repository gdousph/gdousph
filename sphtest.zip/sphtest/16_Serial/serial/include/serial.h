#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 
#include <string.h> 
#include "signal.h"
#include <poll.h>
#include "gpio.h"
#include <termios.h>
#include <errno.h>


#define SERIAL_PATH "/dev/ttymxc2"                   //串口设备

typedef struct uart_hardware_cfg                     //调用串口结构体
{  
    unsigned int baudrate; /* 波特率 */ 
    unsigned char dbit; /* 数据位 */ 
    char parity; /* 奇偶校验 */ 
    unsigned char sbit; /* 停止位 */ 

} uart_cfg_t;


class serial
{
private:
    /* data */
public:
    static struct termios old_cfg; //用于保存终端的配置参数
    int fd;                        //文件描述符号

    
    int uart_init(const char* device);       //串口初始化
    int uart_cfg(const uart_cfg_t *cfg);     //串口配置
    void show_help(const char *app);         //帮助指引
    // static void io_handler(int sig, 
    //                        siginfo_t *info, 
    //                        void *context);          //信号处理函数
    int get_fd();                                   //获取文件描述符
    int Async_ioinit_serial(int fd);
    serial(/* args */);                             
    ~serial();
};

    
// int transfer(int fd);

extern serial port;




#endif // __SERIAL_H