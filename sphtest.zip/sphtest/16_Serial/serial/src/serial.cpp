#include "serial.h"


struct termios serial::old_cfg;
serial port;

serial::serial(/* args */)
{

}                            
serial::~serial()
{

}

//初始化函数
//返回值 0 -1
//返回为0成功 -1为失败
int serial::uart_init(const char* device)
{
    //首先打开设备
    fd = open(device, O_RDWR|O_NOCTTY);
    if(0 > fd) 
    {
        perror("open");
        return -1;
    }

    //获取当前串口配置
    if(0 > tcgetattr(fd, &old_cfg))
    {
        perror("tcgetattr");
        close(fd);
        return -1;
    }

    return 0;
}

//串口配置
int serial::uart_cfg(const uart_cfg_t *cfg)
{
    struct termios new_cfg = {0}; //将 new_cfg 对象清零 
    speed_t speed;

    //设置原始模式
    cfmakeraw(&new_cfg); 
    //使能接收
    new_cfg.c_cflag |= CREAD;

    /* 设置波特率 */ 
    switch (cfg->baudrate) 
    { 
        case 1200: speed = B1200; 
        break; 
        case 1800: speed = B1800; 
        break; 
        case 2400: speed = B2400; 
        break; 
        case 4800: speed = B4800; 
        break; 
        case 9600: speed = B9600; 
        break; 
        case 19200: speed = B19200; 
        break; 
        case 38400: speed = B38400; 
        break; 
        case 57600: speed = B57600; 
        break; 
        case 115200: speed = B115200; 
        break; 
        case 230400: speed = B230400; 
        break; 
        case 460800: speed = B460800; 
        break; 
        case 500000: speed = B500000; 
        break; 
        default: //默认配置为 115200 
        speed = B115200; 
        printf("default baud rate: 115200\n"); 
        break; 
    } 
    //将波特率写入
    if(0 >cfsetspeed(&new_cfg,speed))
    {
        perror("speed");
        return -1;
    }
    //设置数据位
    new_cfg.c_cflag &= ~CSIZE; //将数据位相关的比特位清零
    switch (cfg->dbit) 
    { 
    case 5: 
        new_cfg.c_cflag |= CS5; 
        break; 
    case 6: 
        new_cfg.c_cflag |= CS6; 
        break; 
    case 7: 
        new_cfg.c_cflag |= CS7; 
        break; 
    case 8: 
        new_cfg.c_cflag |= CS8; 
        break; 
    default: //默认数据位大小为 8 
        new_cfg.c_cflag |= CS8; 
        printf("default data bit size: 8\n"); 
        break; 
    } 
    /* 设置奇偶校验 */ 
    switch (cfg->parity)
    { 
    case 'N': //无校验 
        new_cfg.c_cflag &= ~PARENB; 
        new_cfg.c_iflag &= ~INPCK; 
        break; 
    case 'O': //奇校验 
        new_cfg.c_cflag |= (PARODD | PARENB); 
        new_cfg.c_iflag |= INPCK; 
        break; 
    case 'E': //偶校验 
        new_cfg.c_cflag |= PARENB; 
        new_cfg.c_cflag &= ~PARODD; /* 清除 PARODD 标志，配置为偶校验 */ 
        new_cfg.c_iflag |= INPCK; 
        break; 
    default: //默认配置为无校验 
        new_cfg.c_cflag &= ~PARENB; 
        new_cfg.c_iflag &= ~INPCK; 
        printf("default parity: N\n"); 
        break; 
    } 
    /*设置停止位*/
    switch (cfg->sbit) 
    { 
    case 1: //1 个停止位 
        new_cfg.c_cflag &= ~CSTOPB; 
        break; 
    case 2: //2 个停止位 
        new_cfg.c_cflag |= CSTOPB; 
        break; 
    default: //默认配置为 1 个停止位 
        new_cfg.c_cflag &= ~CSTOPB; 
        printf("default stop bit size: 1\n"); 
        break; 
    }
    /* 将 MIN 和 TIME 设置为 0 */ 
    new_cfg.c_cc[VTIME] = 0; 
    new_cfg.c_cc[VMIN] = 0;

    /* 清空缓冲区 */ 
    if (0 > tcflush(fd, TCIOFLUSH)) 
    { 
        fprintf(stderr, "tcflush error: %s\n", strerror(errno)); 
        return -1; 
    } 
 
    /* 写入配置、使配置生效 */ 
    if (0 > tcsetattr(fd, TCSANOW, &new_cfg)) 
    { 
        fprintf(stderr, "tcsetattr error: %s\n", strerror(errno)); 
        return -1; 
    } 
 
 /* 配置 OK 退出 */ 
    return 0; 

}
/*** 
--dev=/dev/ttymxc2 
--brate=115200 
--dbit=8 
--parity=N 
--sbit=1 
--type=read 
***/

void serial::show_help(const char *app) 
{ 
    printf(
            "Usage: %s [选项]\n" 
            "\n 必选选项:\n" 
            " --dev=DEVICE 指定串口终端设备名称, 譬如--dev=/dev/ttymxc2\n" 
            " --type=TYPE 指定操作类型, 读串口还是写串口, 譬如--type=read(read 表示读、write 表示写、其它值无效)\n" 
            "\n 可选选项:\n" 
            " --brate=SPEED 指定串口波特率, 譬如--brate=115200\n" 
            " --dbit=SIZE 指定串口数据位个数, 譬如--dbit=8(可取值为: 5/6/7/8)\n" 
            " --parity=PARITY 指定串口奇偶校验方式, 譬如--parity=N(N 表示无校验、O 表示奇校验、E 表示偶校验)\n" 
            " --sbit=SIZE 指定串口停止位个数, 譬如--sbit=1(可取值为: 1/2)\n" 
            " --help 查看本程序使用帮助信息\n\n",app); 
} 

/** 
 ** 信号处理函数，当串口有数据可读时，会跳转到该函数执行 
 **/ 

static void io_handler(int sig, siginfo_t *info, void *context) 
{ 
   
    char card_buf[30] ={0};
    int ret; 
    int n;
    const char *startDelimiter = "??¨￡o";
    const char *endDelimiter = "@";
    char *cardNumber = NULL;
    char *pData = NULL;
    char *context1 = NULL;

    if(SIGRTMIN != sig) 
    return; 
 
    /* 判断串口是否有数据可读 */ 
    if (POLL_IN == info->si_code) 
    { 
        ret = read(port.fd, card_buf, sizeof(card_buf)); //一次最多读 8 个字节数据 
        printf("%s", card_buf);
        cardNumber = strstr(card_buf,startDelimiter);
        if(cardNumber != NULL)
        {
            cardNumber += strlen(startDelimiter); // 移动到卡号的开始位置
            pData = strstr(cardNumber, endDelimiter); // 查找数据的结束位置
            if(pData != NULL)
            {
                *pData = '\0'; // 用字符串结束符替换结束标识，截断卡号字符串
                context1 = pData + 1; // 移动到数据的开始位置
                printf("卡号： %s@”",cardNumber);
                printf("Data:%s\n",context1);
            }
        }else printf("读取失败\n");

        // printf("[ "); 
        // for (n = 0; n < ret; n++) 
        // printf("%d", buf[n]);
        // printf("@"); 
        // printf("]\n");
        //memset(card_buf, 0, sizeof(card_buf)); 
    } 

} 

int serial::get_fd()
{
    int id = fd;
    return id;
}

//异步Io初始化
int serial :: Async_ioinit_serial(int fd)
{
    int flag;
    struct sigaction sig;

    //异步设置
    flag = fcntl(fd,F_GETFL);
    flag |= O_ASYNC;
    fcntl(fd,F_SETFL,flag); 

    //设置异步拥有者
    fcntl(fd,F_SETOWN,getpid());
    //设置异步触发信号
    fcntl(fd, F_SETSIG, SIGRTMIN);

     
    //设置信号函数
    sig.sa_sigaction = io_handler;
    sig.sa_flags     = SA_SIGINFO;
    sigemptyset(&sig.sa_mask); 
    sigaction(SIGRTMIN, &sig, NULL);
    return fd;
}