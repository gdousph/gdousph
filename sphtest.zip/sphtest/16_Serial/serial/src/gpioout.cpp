#include "gpio.h"

gpio::gpio()
{
    printf("欢迎使用sph的IO库 \r \n");
}

gpio::~gpio()
{
    
}

int gpio::gpio_config(const char *attr,const char *val)
{
    //设置gpio的属性
    char file_path[100];
    int fd;
    int len;
    //将数据输入缓冲区
    sprintf(file_path,"%s/%s",gpio_path,attr);

    //打开文件
    fd = open(file_path,O_WRONLY);
    if(0>fd)
    {
        perror("open");
        return fd;
    }

    //获取指令长度
    len = strlen(val);
    //写入io操作
    if(len != write(fd,val,len))
    {
        perror("write");
        close(fd);
        return false;
    }

    close(fd);

    return 0;
}

void gpio::set_gpiopath(char* io)
{
    sprintf(gpio_path, "/sys/class/gpio/gpio%s", io); 
} 

char* gpio::get_gpiopath()
{
    return gpio_path;
}

void gpio::determine_io_open(char *io_path,char *argv)
{
    if (access(io_path, F_OK))
    { 
        int fd; 
        int len; 
 
        if (0 > (fd = open("/sys/class/gpio/export", O_WRONLY)))
        { 
            perror("open error"); 
            exit(-1); 
        } 
 
        len = strlen(argv); //导出 gpio
        if (len != write(fd, argv, len)) 
        { 

            perror("write error"); 
            close(fd); 
            exit(-1); 
        } 
 
        close(fd); //关闭文件 

    }
}

void gpio::Io_Output(const char *vaule,const char* active)
{
    /* 配置为输出模式 */ 
    if(gpio_config("direction", "out")) 
        exit(-1); 
 
    /* 极性设置 */ 
    if(gpio_config("active_low", active)) 
        exit(-1); 
 
    /* 控制 GPIO 输出高低电平 */ 
    if(gpio_config("value", vaule)) 
        exit(-1); 
}

//io 输入
void gpio::Io_Intput(const char* active)
{
    /* 配置为输出模式 */ 
    if(gpio_config("direction", "in")) 
        exit(-1); 

    /* 极性设置 */   
    if(gpio_config("active_low", active)) 
        exit(-1); 
    printf("debug \r\n");
    /*设置非中断模式*/   
    if(gpio_config("edge", "none"))
        exit(-1); 
    printf("debug \r\n");
}

//io读取
void  gpio::Io_Read()
{
    char file_path[100];
    char val;
    /* 读取 GPIO 电平状态 */ 
    sprintf(file_path, "%s/%s", gpio_path, "value"); 
 
    if (0 > (fd = open(file_path, O_RDONLY))) 
    { 
        printf("error");
        exit(-1); 
    } 
 
    if (0 > read(fd, &val, 1)) { 
        printf("read error"); 
        close(fd); 
        exit(-1); 
    } 
 
    printf("value: %c\n", val);
    printf("succeessddd \r\n");
    
}

void gpio::Io_intrrupt(const char* interrupt_num,const char* Trigger_Mode)
{
     /* 配置为输入模式 */ 
     printf("succeessddd \r\n");
    if (gpio_config("direction", "in")) 
    exit(-1); 
 
    /* 极性设置 默认为低极性 不做更改 */ 
    printf("succeessddd \r\n");
    if (gpio_config("active_low", "0")) 
    exit(-1);
    /*中断模式 以及中断的触发方式*/
    printf("succeessddd \r\n");
    if(gpio_config(interrupt_num,Trigger_Mode))
    exit(-1);
}

//采用异步IO的方式处理中断,使用信号的方式
void gpio::Io_intrrupt_handle(int sig)
{   
    if(SIGRTMIN != sig)
    {
        printf("Io_intrrupt_handle");
        exit(0);
    }
    printf("已开门\r \n");
    exit(0);

}

//异步Io初始化
int gpio :: Async_ioinit(int fd)
{
    int flag;
    struct sigaction sig;

    //异步设置
    flag = fcntl(fd,F_GETFL);
    flag |= O_ASYNC;
    fcntl(fd,F_SETFL,flag); 

    //设置异步拥有者
    fcntl(fd,F_SETOWN,getpid());
    //设置异步触发信号
    fcntl(fd, F_SETSIG, SIGRTMIN);

    signal(SIGRTMIN, Io_intrrupt_handle); 
    //设置信号函数
    // sig.sa_sigaction = Io_intrrupt_handle;
    // sig.sa_flags     = SA_SIGINFO;
    // sigemptyset(&sig.sa_mask); 
    // sigaction(SIGRTMIN, &sig, NULL);
    return fd;
}

//poll轮寻接口 使用时完善
// void gpio::pollhandler()
// {
//             ret = poll(&pfd,1,-1);
//         if (0 > ret) 
//         { 
//             perror("poll error"); 
//             exit(-1); 
//         }
//         else if (0 == ret) 
//         { 
//             fprintf(stderr, "poll timeout.\n"); 
//             continue; 
//         } 
//         if(pfd.revents & POLLPRI) 
//         {             
//             if(0 > lseek(pfd.fd, 0, SEEK_SET)) 
//             {//将读位置移动到头部                 
//             perror("lseek error");                 
//             exit(-1);             
//         }   
//             if (0 > read(pfd.fd, &val, 1)) 
//             {                 
//                 perror("read error");                 
//                 exit(-1);             
//             }
//             printf("111 \r\n");
//             kill(getpid(),SIGUSR1);
//         }
// }