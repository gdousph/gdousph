#include <pthread.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <stdio.h>
#include "stdlib.h"

static void * pthread_handle(void * arg)
{
    printf("这是一个线程，其中进程号为：%d，线程号为：%lu\r\n",getpid(),pthread_self());
    return ((void *)15);
}

int main(int argc, char ** argv)
{
    pthread_t newThread;
    
    void *rts;

    //创建线程
    if(0 > pthread_create(&newThread, NULL,pthread_handle,NULL))
    {
        perror("why");
        exit(-1);
    }
    else printf("create succssed! \r \n");

    
    if(0 > pthread_join(newThread,&rts))
    {
        perror("why");
        exit(-1);
    }

    printf("新线程终止, code=%ld\n", (long)rts);
    sleep(1);
    exit(0);
}