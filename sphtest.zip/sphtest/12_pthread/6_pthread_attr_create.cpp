#include <pthread.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <stdio.h>
#include "stdlib.h"

#define K4 4096

static void * pthread_handle(void * arg)
{
    //分离线程自己
    puts("hello world");

    return (void *)0;
}

int main(int argc, char ** argv)
{
    pthread_t newThread;
    
    void *rts;
    int ret1;

    pthread_attr_t attr;

    //设置4k大小的线程
    pthread_attr_init(&attr);

    pthread_attr_setstacksize(&attr,K4);
    //设置分离属性
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED); 

    //创建线程
    if(0 > pthread_create(&newThread, &attr,pthread_handle,NULL))
    {
        perror("why");
        exit(-1);
    }
    else printf("create succssed! \r \n");

    sleep(1);
    // 回收线程  
    ret1 = pthread_join(newThread,&rts);
    if(ret1)
    {
        fprintf(stderr, "pthread_join error: %s\n", strerror(ret1)); 
        
    }
    


    pthread_attr_destroy(&attr);
    exit(0);
}