//此进程进行数据的写入
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include  <strings.h>

#define _FIFO_PATH "./myfifo.ipc"

int main(int argc, char **argv)
{
    int fd;
    fd = open(_FIFO_PATH, O_RDWR|O_TRUNC );
    if(0 > fd) 
    {
        perror("open");
        exit(-1);
    }
    else printf("open succssed! \r\n");

    //数据的写入
    char writebuffer[1024];
    while(true)
    {
        printf("请写入数据\r\n");
        scanf("%s",writebuffer);
        printf("%s",writebuffer);
        ssize_t size = write(fd,writebuffer,sizeof(writebuffer)); 
        if(0>size)
        {
            perror("write");
            exit(-1);
        }
        else if (0==size)
        {
            printf("no loading \n");
        }
        
    }

    close(fd);
    exit(0);
}