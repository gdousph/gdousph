//此进程进行数据的读取
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>

#define _FIFO_PATH "./myfifo.ipc"

using namespace std;

int main(int argc, char** argv)
{
    int ret;
    int fd;
    //创建文件管道 
    ret = mkfifo(_FIFO_PATH,0777);
    if(0 > ret && errno != EEXIST)
    {
        perror("mkfifo");
    }
    else printf("mkfifo started\n");

    //打开文件管道
    fd = open(_FIFO_PATH,O_RDONLY);
    if(0 > fd)
    {
        perror("open");
        exit(-1);
    }
    else printf("FIFO open susscced! \r\n");

    //进行通信,一直读
    char readbuf[8000];
    while (true)
    {
        //清空缓存
        memset(readbuf,0,sizeof(readbuf));
        ssize_t size = read(fd,readbuf,sizeof(readbuf));
        if(size < 0)
        {
            perror("read error");
            exit(-1);
        }
        else if (size == 0)
        {
            // printf("buf is empty\n");
        }
        else 
            printf("%s\n",readbuf);
            fflush(stdout);
        
        // sleep(5);
        
    }
    
    

    close(fd);
    exit(0);
}

