//互斥锁demo
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h> 
#include <unistd.h> 
#include <string.h>


static pthread_mutex_t mutex;
static int g_count;


static void *handle(void *arg)
{
    int loops = *((int*)arg);
    int l_count, j;
    for(j = 0;j<loops;j++)
    {
        pthread_mutex_lock(&mutex);
        l_count = g_count;
        l_count++;
        g_count = l_count;
        pthread_mutex_unlock(&mutex);
    }

    return (void*)0;
}
static int loops;

int main(int argc, char **argv)
{
    pthread_t tid1, tid2; 
    int ret;
    //初始化线程锁
    pthread_mutex_init(&mutex, NULL); 
    //创建线程
    loops = 1000000;
    pthread_create(&tid1,NULL,handle,&loops);
    if (ret) 
    { 
        fprintf(stderr, "pthread_create error: %s\n", strerror(ret)); 
        exit(-1); 
    } 
    
    pthread_create(&tid2,NULL,handle,&loops);
    if (ret) 
    { 
        fprintf(stderr, "pthread_create error: %s\n", strerror(ret)); 
        exit(-1); 
    } 
    

    //等待线程结束
    ret = pthread_join(tid1, NULL); 
    if (ret) 
    { 
        fprintf(stderr, "pthread_create error: %s\n", strerror(ret)); 
        exit(-1); 
    } 

    ret = pthread_join(tid2, NULL); 
    if (ret) 
    { 
        fprintf(stderr, "pthread_create error: %s\n", strerror(ret)); 
        exit(-1); 
    } 

    //打印输出结果
    printf("sum = %d",g_count);

    pthread_mutex_destroy(&mutex);

    exit(0);
}