//模拟生产者和消费者之间的关系 使用互斥锁和条件变量实现
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> 
#include <string.h>

static pthread_mutex_t mutex;
static pthread_cond_t cond;
static int rmb;

//线程模拟消费者，设定死循环 在条件满足后往下运行 节省系统开销
static void * thread_handle(void *arg)
{
    for(;;)
    {   
        //设定互斥锁
        pthread_mutex_lock(&mutex);

        //检测是否有钱,并设置条件变量
        while (rmb <= 0 )pthread_cond_wait(&cond,&mutex);
        printf("赚到钱拉拉\n\r , rmb = %d \r\n",rmb);
        
        while (rmb >0)rmb--;

        
        
        pthread_mutex_unlock(&mutex);

    }

     return (void*)0;

}

int main()
{
    pthread_t tid;
    int ret;
    //初始化锁和进程以及条件变量
    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&cond,NULL);

    ret = pthread_create(&tid,NULL,thread_handle,NULL);
    if (ret) 
    { 
        fprintf(stderr, "pthread_create error: %s\n", strerror(ret)); 
        exit(-1); 
    }

    //生产者赚园子
    for(;;)
    {
        pthread_mutex_lock(&mutex);

        rmb++;

        pthread_mutex_unlock(&mutex);
        pthread_cond_signal(&cond);
    }

    
    exit(0);
}