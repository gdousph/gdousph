#ifndef __GPIO_H
#define __GPIO_H

#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 
#include <string.h> 
#include "signal.h"
#include <poll.h>

#define _GNU_SOURCE

#define High_level_ "1"
#define Low_level_  "0"

class gpio
{
private:
    int ret;                                       //调试变量
    char gpio_path[100];                           //gpio_path
        
public:
    char gpio_name[100];                           //gpio的名字
    int len;                                       //gpio的数据长度
    int fd;                                        //gpio的文件描述符

    int gpio_config(const char *attr,
                    const char *val);              //配置gpio的函数
    void set_gpiopath(char* io);                   //配置io口参数
    char* get_gpiopath();                          //获取io口参数
    void determine_io_open(char *io_path,
                           char *argv);            //判断io口是否导出

    void Io_Output(const char *vaule,
                   const char* active);            //设置IO输出
    void Io_Intput(const char* active);            //设置IO输入

    void Io_Read();                                //读取IO电平
    void Io_intrrupt(const char* interrupt_num,
                     const char* Trigger_Mode);    //设置IO中断
    int Async_ioinit(int fd);
    static void Io_intrrupt_handle(int sig);        //IO中断设置 


    gpio();
    ~gpio();
};














#endif
