//主程序，确保可移值性，将驱动分离
 //在源文件开头定义_GNU_SOURCE 宏
#include "gpio.h"



int main(int argc, char** argv)
{
    int fd;
    gpio gp;
    char gp_path[100];
    char val;
    //校验传参
    if (3 != argc)
    { 
        fprintf(stderr, "usage: %s <gpio> <value>\n", argv[0]); 
        exit(-1); 
    }
    //设置与获取gpio参数
    gp.set_gpiopath(argv[1]);
    strcpy(gp_path,gp.get_gpiopath());

    //判断是否导出io口，如果目录不存在 则需要导出
    gp.determine_io_open(gp_path,argv[1]);
    //中断初始化
    gp.Io_intrrupt("edge", "both");
    //开启gpio设备
    fd = open("/sys/class/gpio/gpio1/value", O_RDONLY|O_NONBLOCK);
    //异步初始化
    fd = gp.Async_ioinit(fd);

    struct pollfd pfd;
    pfd.fd = fd;
    pfd.events = POLLPRI;
    read(pfd.fd, &val, 1);//先读取一次清除状态
    int ret;
    
    for(;;)
    {
        ret = poll(&pfd,1,-1);
        if (0 > ret) 
        { 
            perror("poll error"); 
            exit(-1); 
        }
        else if (0 == ret) 
        { 
            fprintf(stderr, "poll timeout.\n"); 
            continue; 
        } 
        if(pfd.revents & POLLPRI) 
        {             
            if(0 > lseek(pfd.fd, 0, SEEK_SET)) 
            {//将读位置移动到头部                 
            perror("lseek error");                 
            exit(-1);             
        }   
            if (0 > read(pfd.fd, &val, 1)) 
            {                 
                perror("read error");                 
                exit(-1);             
            }
            printf("111 \r\n");
            kill(getpid(),SIGUSR1);
        }
    }
    //设置输出

    //gp.Io_Read();
    
    exit(0);  

}