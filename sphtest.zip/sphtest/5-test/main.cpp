#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    //创建文件描述符
    char buf[] = {"Hello World!"};
    char readbuf[50]={0};
    int ret;
    FILE *fp = NULL;
    fp = fopen("./hello","w+");
    if(NULL == fp)
    {
        perror("Open Failed");
        exit(-1);
    }

    // cout << "文件开启成功" << endl;

    if(sizeof(buf)>fwrite(buf,1,sizeof(buf),fp))
    {
        perror("Write Failed");
        fclose(fp);
        exit(-1);
    }

    if(0>(ret = ftell(fp)))
    {
        perror("Write Failed");
        fclose(fp);
        exit(-1);
    }
    printf("文件偏移位置为 %d \r \n",ret);

    cout << "数据写入成功"<<endl;

    if(0>(fseek(fp,0,SEEK_SET)))
    {
        perror("seek error");
        exit(-1);
    }

    if(12>(ret = fread(readbuf,sizeof(char),sizeof(readbuf),fp)))
    {
        printf("%d",ret);
        if(ferror(fp))
        {
            perror("read faild:");
            fclose(fp);
            exit(-1);
        }
    }

    printf("读取到%d个字节的数据为 %s",ret,readbuf);

    fclose(fp);

    return 0;
} 