#ifndef __CAN_H
#define __CAN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
 
#include <linux/can.h>
#include <linux/if.h>
#include <linux/can/raw.h>


#define CAN_DOWN "ip link set can0 down"
#define CAN_UP   "ip link set can0 up"
#define CAN_SET  "ip link set can0 type can bitrate 500000"


class can
{
public:
    int fd;

    int can_init();
    int can_read(int can_id,char data[8]);
    int can_write(int can_id,char data[8],int data_len);

    can();
    ~can();

private:
    
};

#endif 
