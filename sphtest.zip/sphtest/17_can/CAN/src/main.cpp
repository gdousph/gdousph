//主程序，确保可移值性，将驱动分离
 //在源文件开头定义_GNU_SOURCE 宏
#include "gpio.h"
#include "serial.h"
#include "can.h"

extern serial port;


int main(int argc, char** argv)
{
    can c;
    int ret = 0;
    ret = c.can_init();
    if(-1 ==ret)
    {
        printf("init_error\r\n");
        return -1;
    }
    char data[0]={};

    for(;;)
    {
        sleep(2);
        c.can_read(0x01, data);
    }

    printf("11");

    exit(EXIT_SUCCESS); 
     
}