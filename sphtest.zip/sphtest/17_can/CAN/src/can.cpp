#include "can.h"


typedef struct
{
  unsigned int StdId;    /* CAN标准帧ID，占11bit，范围：0~0x7FF */ 
  unsigned int ExtId;    /* CAN扩展帧ID，占29bit，范围：0~0x1FFFFFFF */ 
  unsigned char IDE;     /* CAN报文ID类型，CAN_ID_STD 或 CAN_ID_EXT */
  unsigned char RTR;     /* CAN报文类型，CAN_RTR_DATA 或 CAN_RTR_REMOTE */ 
  unsigned char DLC;     /* CAN报文数据长度， 范围：0~8  */ 
  unsigned char Data[8]; /* CAN报文数据内容，每个字节范围：0~0xFF*/
} CanTxMsg;
 
typedef struct
{
  unsigned int StdId;    /* CAN标准帧ID，范围：0~0x7FF */ 
  unsigned int ExtId;    /* CAN扩展帧ID，范围：0~0x1FFFFFFF */ 
  unsigned char IDE;     /* CAN报文ID类型，CAN_ID_STD 或 CAN_ID_EXT */
  unsigned char RTR;     /* CAN报文类型，CAN_RTR_DATA 或 CAN_RTR_REMOTE */ 
  unsigned char DLC;     /* CAN报文数据长度， 范围：0~8  */ 
  unsigned char Data[8]; /* CAN报文数据内容，每个字节范围：0~0xFF*/
  unsigned char FMI;     /* 过滤模式，总共有14中，定义有宏，其值依次为0x1,0x2,0x4,0x8,0x10,0x20,0x40……,此处可以不考虑，忽略*/
} CanRxMsg;

can :: can()
{
    printf("sph 的can库已就绪 \r\n");
}
can::~can()
{
    
}

int can :: can_init()
{
    //设置can的波特率
    system(CAN_DOWN);
    system(CAN_SET);
    system(CAN_UP);

    //创建 can的socket套接字
    int ret;
    fd = socket(AF_CAN,SOCK_RAW,CAN_RAW);
    if(0 > fd) 
    {
        printf("open error \r \n");
        return -1;
    }

    //将套接字绑定到端口
    struct sockaddr_can addr;
    struct ifreq ifr;
    strcpy(ifr.ifr_name, "can0");        //设定名称
    ioctl(fd, SIOCGIFINDEX, &ifr);  //获取接口索引
    memset(&addr, 0, sizeof(addr));
    addr.can_family =  AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    //绑定can接口
    ret = bind(fd,(struct sockaddr*)&addr,sizeof(addr));
    if(0 > ret)
    {
        printf("bind error \r\n");
        return -1;
    }

    //设置can的过滤规则 过滤掉0x201的所有信息
    #if 0
    struct can_filter recv_filter;
    recv_filter.can_id = 0x201;
    recv_filter.can_mask = CAN_SFF_MASK;
    setsockopt(*can_fd, SOL_CAN_RAW, CAN_RAW_FILTER, &recv_filter, sizeof(recv_filter));    
    #endif

    //设置读写为非阻塞模式
    int flags;
    flags = fcntl(fd,F_GETFL);
    flags |= O_NONBLOCK;
    fd = fcntl(fd,F_SETFL,flags);

    return 0;

}

//can读取数据
int can::can_read(int can_id,char data[8])
{
    //如果没有文件描述符，返回
    if(-1 == fd)
    {
        printf("file error \r\n");
        return -1;
    }
    // 设置can_frame 结构体来进行数据祯的获取
    int ret = 0;
    struct can_frame recv_data;
    recv_data.can_id = can_id;
    recv_data.can_dlc = 8;

    ret = read(fd,&recv_data,sizeof(struct canfd_frame));
    if(-1 == ret)
    {
        perror("read");
        return -1;
    }
    else
    {
        //将读到的数据放入data缓冲区
        memcpy(data,&recv_data.data[0],recv_data.can_dlc);
        if(recv_data.can_id != can_id)
        {
            printf("error");
            return -1;
        }

        //打印参数
        printf("ID=%03x,DLC=%d \r\n,data = %02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x",\
        recv_data.can_id,recv_data.can_dlc,\
        recv_data.data[0],\
        recv_data.data[1],\
        recv_data.data[2],\
        recv_data.data[3],\
        recv_data.data[4],\
        recv_data.data[5],\
        recv_data.data[6],\
        recv_data.data[7]);
    }
    return 0;

}

//写入数据
int can::can_write(int can_id,char data[8],int data_len)
{
    int ret;
    CanRxMsg msg;
    struct can_frame send_data;
    if(-1 == fd)
    {
        printf("wirte error\r\n");
        return -1;
    }
    send_data.can_dlc = data_len;
    send_data.can_id  = can_id;
    memcpy(&send_data.data[0], data, data_len);
    ret = write(fd,&send_data,sizeof(struct canfd_frame));
    if(-1 == ret)
    {
        perror("write");
        return -1;
    }
    else
    {
        printf("ID=%03x,DLC=%d \r\n,data = %02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x",\
        send_data.can_id,send_data.can_dlc,\
        send_data.data[0],\
        send_data.data[1],\
        send_data.data[2],\
        send_data.data[3],\
        send_data.data[4],\
        send_data.data[5],\
        send_data.data[6],\
        send_data.data[7]);
    }


}
