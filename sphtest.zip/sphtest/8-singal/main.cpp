#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

static void DealSignalHandler(int sig, siginfo_t *info, void *context)
{
    
    sigval_t sig_val = info->si_value; 
    printf("接收到实时信号: %d\n", sig); 
    printf("伴随数据为: %d\n", sig_val.sival_int);
}

int main(int argc, char **argv)
{
    int ret = 0;
    int num = 0;

    struct sigaction sig = {0};
    /* 判断传参个数 */ 
    if (2 > argc) 
    exit(-1); 
 
    /* 获取用户传递的参数 */ 
    num = atoi(argv[1]); 

    sig.sa_sigaction = DealSignalHandler;
    sig.sa_flags   = SA_SIGINFO;

    ret = sigaction(num, &sig, NULL);
    if(-1 == ret)
    {
        perror("deal signal");
        exit(-1);
    }

    for(;;)
    {}
    
    return 0;
}