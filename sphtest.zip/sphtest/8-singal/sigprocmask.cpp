#include <stdio.h> 
#include <stdlib.h> 
#include <signal.h> 
#include <unistd.h> 

static void signal_handler(int sig)
{
    printf("hello \r \n");
}

int main(int argc, char **argv)
{
    struct sigaction sig = {0};
    sigset_t sig_set;

    sig.sa_handler = signal_handler;
    sig.sa_flags = 0;
    if(-1 == sigaction(SIGINT, &sig, NULL))exit(-1);

    sigemptyset(&sig_set);
    sigaddset(&sig_set,SIGINT);

    if (-1 == sigprocmask(SIG_BLOCK, &sig_set, NULL)) 
    exit(-1); 

    raise(SIGINT);

    sleep(3);
    printf("sleep down \n");

    if(-1 == sigprocmask(SIG_UNBLOCK,&sig_set,NULL))
    exit(-1);

}