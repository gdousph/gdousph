#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h> 

static void DealSignalHandler(int sig)
{
    printf("deal signal: %d\n", sig);
}

int main(int argc, char **argv)
{
    int ret = 0;

    struct sigaction sig = {0};

    sig.sa_handler = DealSignalHandler;
    sig.sa_flags   = 0;

    ret = sigaction(SIGINT, &sig, NULL);
    if(-1 == ret)
    {
        perror("deal signal");
        exit(-1);
    }

    for(;;)
    {
        if(-1 == raise(SIGINT))
        {
            perror("deal signal");
            exit(-1);
        }

        sleep(3);
    }
    
    return 0;
}