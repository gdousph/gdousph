#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int main(int argc, char **argv)
{
    int pid;
    int sig;
    union sigval sig_val;
    //判断输入参数
    if (3 > argc)
    {
        printf("Usage error");
        exit(-1);
    }
    //将获得的进程数与pid号打印
    pid = atoi(argv[1]);
    sig = atoi(argv[2]);
    printf("pid = %d\nsig = %d\n", pid, sig);

    //发送伴随信号
    sig_val.sival_int = 10;
    if(-1 == sigqueue(pid,sig,sig_val))
    {
        perror("sigqueue error:");
        exit(-1);
    }

    puts("信号发送成功!");


    return 0;
}