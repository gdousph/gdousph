#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h> 

static void algrm_handler(int sig)
{

    printf(" What Can I Say Time Out\r \n");
    // raise(SIGTERM);
}

int main(int argc, char **argv)
{
    struct sigaction sig = {0};
    int second;

    if(2 > argc)
    {
        //参数过多报错退出
        exit(-1);
    }
    
    sig.sa_flags = 0;
    sig.sa_handler = algrm_handler;
    if(-1 == sigaction(SIGALRM, &sig, NULL))
    {
        perror("hello error");
        exit(-1);
    }
     printf("qidong");
    /* 启动 alarm 定时器 */ 
    second = atoi(argv[1]); 
    printf("定时时长: %d 秒\n", second); 
    alarm(second);
    // while (true)
    // {
    //     sleep(1);
    // }
    
    pause();
    printf("sleep done \r \n");

    exit(0);

}