// #define _GNU_SOURCE //在源文件开头定义_GNU_SOURCE 宏

#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 
#include "poll.h"
#include "signal.h"

#define Mouse "/dev/input/mouse0"
static int fd;

//信号处理函数 使用 sigraction函数 进行处理
static void sighandle(int sig, 
                      siginfo_t *info, 
                      void *context)
{
    static int loops = 5; 
    char buf[100] = {0}; 
    int ret; 
    if(SIGRTMIN != sig)
    {
        exit(0);
    }
    if (POLL_IN == info->si_code) { 
        ret = read(fd, buf, sizeof(buf)); 
        if (0 < ret) 
        printf("鼠标: 成功读取<%d>个字节数据\n", ret); 
 
        loops--; 
        if (0 >= loops) { 
        close(fd); 
        exit(0); 
 } 
 }

    


}

int main(int argc, char **argv)
{   
    int flag;
    struct sigaction sig;
    fd = open(Mouse, O_RDONLY|O_NONBLOCK);

    //异步设置
    flag = fcntl(fd,F_GETFL);
    flag |= O_ASYNC;
    fcntl(fd,F_SETFL,flag); 

    //设置异步拥有者
    fcntl(fd,F_SETOWN,getpid());
    //设置信号
    fcntl(fd, F_SETSIG, SIGRTMIN);

    //设置信号函数
    sig.sa_sigaction = sighandle;
    sig.sa_flags     = SA_SIGINFO;
    sigemptyset(&sig.sa_mask); 
    sigaction(SIGRTMIN, &sig, NULL);

    for(;;)
    {
        sleep(1);
        printf("hello \r\n");
    }
    


}
