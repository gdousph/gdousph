#include <iostream>
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define DeviceName "/dev/input/mouse0"

int main(int argc, char **argv)
{
    int ret,fd;
    char buffer[100];

    fd  = open(DeviceName, O_RDONLY|O_NONBLOCK);
    if(0 > fd)
    {
        perror("problem");
        exit(-1);
    }else printf("open file succed \r\n");

    ret = read(fd, buffer, sizeof(buffer));
    if(0 > ret)
    {
        perror("problem");
        exit(-1);
    }else printf("read file succed \r\n"); 

    //打印读取到的内容
    printf("%s\r\n", buffer);

    return(0);
    
}