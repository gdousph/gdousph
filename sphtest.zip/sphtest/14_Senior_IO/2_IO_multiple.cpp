#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 
#include <sys/select.h>

#define Mouse "/dev/input/mouse0"

int main(int argc, char **argv)
{
    
    int fd;
    int ret;
    int flag;
    char mouse_buf[100];
    char keyboard_buf[100];
    fd_set rdfds; 
    int loops = 5; 

    //开启鼠标并启动非阻塞模式打开
    fd = open(Mouse, O_RDONLY|O_NONBLOCK);
    if(0 > fd)
    {
        perror("open");
        exit(-1);
    }

    //开启键盘
    flag = fcntl(0,F_GETFL);  //获取键盘标志
    flag |= O_NONBLOCK;       //添加非阻塞标志
    fcntl(0,F_SETFL,flag);    //重新设置标志

    //开启事件
    while (loops--)
    {
        //读取鼠标和键盘
        FD_ZERO(&rdfds);
        FD_SET(0,&rdfds);
        FD_SET(fd,&rdfds);

        ret = select(fd+1,&rdfds,NULL,NULL,NULL);
        if(0 > ret)
        {
            perror("why");
            exit(-1);
        }
        else if (0 == ret)
        {
            fprintf(stderr,"select error ");
            continue;
        }

        //读取键盘数据
        if(FD_ISSET(0,&rdfds))
        {
            ret = read(0,mouse_buf,sizeof(mouse_buf));
            if(0 < ret)
            {
                printf("读取到的字节为 <%d> \n",ret);
            }
        }

        //读取鼠标数据
        if(FD_ISSET(fd,&rdfds))
        {
            ret = read(fd,mouse_buf,sizeof(mouse_buf));
            if(0 < ret)
            {
                printf("读取到的字节为 <%d> \n",ret);
            }
        }


    }
    
    close(fd);
    return 0;

}