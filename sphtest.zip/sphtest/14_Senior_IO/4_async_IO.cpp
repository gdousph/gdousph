#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 
#include "poll.h"
#include "signal.h"

#define Mouse "/dev/input/mouse0"
static int fd;

static void  io_sighandle(int sig)
{
    static int loops = 5; 
    char buf[100] = {0}; 
    int ret; 
    if(SIGIO != sig)
    {
        exit(0);
    }


    ret = read(fd, buf, sizeof(buf));

    printf("read: %d\n", ret);
        loops--; 
        if (0 >= loops) { 
                close(fd); 
                exit(0); 
            } 




}

int main(int argc, char **argv)
{

    int ret;
    int flag;

    fd = open(Mouse, O_RDONLY|O_NONBLOCK);

    //设置异步标志
    flag =fcntl(0,F_GETFL);
    flag |= O_ASYNC;
    fcntl(fd,F_SETFL,flag);

    //设置异步所有者
    fcntl(fd,F_SETOWN,getpid());

    signal(SIGIO,io_sighandle);

    for(;;)
    {
        sleep(1);
        printf("等待唤醒\n");
    }
    
    return 0;

}