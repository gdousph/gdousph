#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 
#include "poll.h"

#define Mouse "/dev/input/mouse0"


int main(int argc, char **argv)
{
    char buf[100]; 
    int fd, ret = 0, flag; 
    int loops = 5; 
    struct pollfd fds[2];

    //开启鼠标并启动非阻塞模式打开
    fd = open(Mouse, O_RDONLY|O_NONBLOCK);
    if(0 > fd)
    {
        perror("open");
        exit(-1);
    }

    //开启键盘
    flag = fcntl(0,F_GETFL);  //获取键盘标志
    flag |= O_NONBLOCK;       //添加非阻塞标志
    fcntl(0,F_SETFL,flag);    //重新设置标志


    fds[0].fd = 0;
    fds[0].events = POLLIN;
    fds[0].revents = 0;
    fds[1].fd = fd;
    fds[1].events = POLLIN;
    fds[1].revents = 0;

    while (loops--)
    {
        ret = poll(fds, 2, -1); 
        if (0 > ret) 
        { 
            perror("poll error"); 
            exit(-1);
        } 
        else if (0 == ret) 
        { 
            fprintf(stderr, "poll timeout.\n"); 
            continue; 
        } 

        if(fds[0].revents & POLLIN) { 
            ret = read(0, buf, sizeof(buf)); 
            if (0 < ret) 
            printf("键盘: 成功读取<%d>个字节数据\n", ret); 
            } 
 
        /* 检查鼠标是否为就绪态 */ 
        if(fds[1].revents & POLLIN) { 
            ret = read(fd, buf, sizeof(buf)); 
            if (0 < ret) 
        printf("鼠标: 成功读取<%d>个字节数据\n", ret); 
        } 
        
    }
    

    close(fd);
    return 0;
}