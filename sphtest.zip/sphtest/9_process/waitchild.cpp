#include <stdio.h> 
#include <stdlib.h> 
#include <signal.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/wait.h>

//使用信号杀死子进程,采用轮寻的方式，当
static void wait_childHandle(int sig)
{
    static int num;
    while (waitpid(-1, NULL, WNOHANG) > 0) 
    {
        ++num;
        continue;
    }

    
    printf("i = %d\r\n", num);
    
}

int main(int argc, char **argv)
{
    struct sigaction sig ={0};
    int n;

    //把信号装入信号掩码中
    sigemptyset(&sig.sa_mask);
    sig.sa_handler = wait_childHandle;
    sig.sa_flags = 0;
    if(-1 == sigaction(SIGCHLD, &sig,NULL))
    {
        perror("singal error:");
        exit(-1);
    }
    if(2>argc)
    {
        printf("Usage:error \r\n");
        exit(-1);
    }
    n = atoi(argv[1]);
    int i;
    for(i=0;i<n;i++)
    {
        switch(fork())
        {
        case -1:
        perror("fork error");
        exit(-1);
        //子进程创建成功
        case 0:
            printf("子进程<%d>被创建\n", getpid()); 
            sleep(2); 
            //printf("子进程 %d号退出\n",(i+1));
            _exit(1);
        default:
            break;
        }
    }
    
    for(;;)
    {}

    

    exit(0);

}