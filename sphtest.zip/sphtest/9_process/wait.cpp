#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/wait.h> 
#include <errno.h>


int main(int argc, char **argv)
{
    int i;
    int num;
    int pid;
    int status;
    int ret;
    if(2>argc)
    {
        printf("Usage:error \r\n");
        exit(-1);
    }
    num = atoi(argv[1]);
    for(i=0;i<num;i++)
    {
        pid = fork();
        switch(pid)
        {
        case -1:
        perror("fork error");
        exit(-1);
        //子进程创建成功
        case 0:
            printf("子进程<%d>被创建\n", getpid()); 
            sleep(i); 
            //printf("子进程 %d号退出\n",(i+1));
            _exit(i);
        default:
            break;
        }
    }


    //父进程处理
    sleep(1);
    printf("~~~~~~~~~~~~~~~~~\n");
    for(;;)
    {
        ret = waitpid(-1, &status, WNOHANG); 
        if(0 > ret)
        {
            if (ECHILD == errno)
            { 
                printf("没有需要等待回收的子进程\n"); 
                exit(0); 
            }
        
        else
        {
            perror("wait:lll");
            exit(-1);
        }
        }
        else if(0 == ret)continue;
        else
        printf("收尸的子进程为：%d,状态为：%d \r \n",ret,WEXITSTATUS(status));
    }
    


}