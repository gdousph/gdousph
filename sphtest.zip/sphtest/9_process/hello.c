#include "stdio.h"
#include "stdlib.h"

extern char ** environ;


int main(int argc,char **argv)
{
    int i;
    for(i=0;NULL != environ[i];i++) puts(environ[i]);

    exit(0);
}
