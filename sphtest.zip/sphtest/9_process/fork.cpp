#include "stdio.h"
#include "stdlib.h"
#include <unistd.h> 

int main(int argc, char **argv)
{
    int pid;
    pid = fork();
    switch (pid) 
    {
        case -1:
        perror("fork error");
        exit(-1);
        case 0:
        printf("子进程信息打印: %d\r\n",getpid());
        printf("这是父进程信息打印：%d \r\n",getppid());
        _exit(0);
        default:
        printf("这是父进程信息打印：%d \r\n",getpid());
        printf("这是子进程信息打印：%d \r\n",pid);
        exit(0);
    }

}