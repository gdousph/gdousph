#include <stdio.h>
#include <stdlib.h>
#include <sys/utsname.h>

int main(int argc, char **argv)
{
    struct utsname InfoSys;
    int ret;

    ret = uname(&InfoSys);
    if(-1 == ret)
    {
        perror("uname");
        exit(-1);
    }
    printf("操作系统名称: %s\n", InfoSys.sysname); 
    printf("主机名: %s\n", InfoSys.nodename); 
    printf("内核版本: %s\n", InfoSys.release); 
    printf("发行版本: %s\n", InfoSys.version); 
    printf("硬件架构: %s\n", InfoSys.machine);

    return 0;
}