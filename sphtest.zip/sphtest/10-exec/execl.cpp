#include <stdio.h>
#include <stdlib.h>
#include "unistd.h"

int main(int argc, char **argv)
{
    if(-1 == execl("/bin/ls","ls","-a","-l",NULL))
    {
        perror("EXECL");
        exit(-1);
    }

    exit(0);

}