#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"

int main(int argc, char **argv)
{

    execlp("ls","ls","-a","-l",NULL);
    perror("hello");

    exit(0);

}