#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"

int main(int argc, char **argv)
{
    char * arr[5];

    arr[0]= "ls";
    arr[1]= "-a";
    arr[2]= "-l";
    arr[3]= NULL;

    execv("/bin/ls", arr);
    perror("execv");

    exit(0);
}