#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <signal.h>

int main(int argc, char **argv)
{
    int i;
    pid_t pid = fork();
    if(0>pid){
        perror("fork");
    }
    else if(0 < pid){
        //父进程
        exit(0);
    }

        //子进程创建会话
        if(0 > setsid())
        {
            perror("setsid");
            exit(-1);
        }

        //设置工作目录到根目录
        if(0 > chdir("/"))
        {
            perror("chdir");
            exit(-1);
        }
        //设置文件掩码
        umask(0);

        //关闭文件描述符
        for (i = 0; i < sysconf(_SC_OPEN_MAX); i++) 
        close(i);

        //将文件描述符定位到/dev/null×里
        open("/dev/null", O_RDWR); 
        dup(0); 
        dup(0);

        //忽略sigchld信号
        signal(SIGCHLD,SIG_IGN);

        //进入守护进程
        for(;;)
        {
            printf("hello \r \n");
        }

    exit(0);
    
}