#include "stdio.h"
#include "stdlib.h"
#include <unistd.h> 

int main(int argc, char **argv)
{
    //设置输入的环境变量
    char *arg_arr[5]; 
    char *env_arr[5] = {"NAME=app", "AGE=25", 
                       "SEX=man", NULL}; 

    arg_arr[0] = argv[1]; 
    arg_arr[1] = "Hello"; 
    arg_arr[2] = "World"; 
    arg_arr[3] = NULL;
    //创建子进程 进行执行新函数
    switch (fork())
    {
    case -1:
        perror("frok error");
        exit(-1);
    case 0:
        printf("子进程 使用exec运行新程序\r\n");
        execve(argv[1],arg_arr,env_arr);
    
    default:
        break;
    }

    //父进程执行
    printf("~~~~~~~~~~~~~~~~~~~~ \r\n");
    sleep(5);
    printf("这是父进程");

}