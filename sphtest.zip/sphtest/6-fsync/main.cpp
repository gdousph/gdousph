#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


#define READ_FILE "./read_file"
#define WRITE_FILE "./write_file"

int main(int argc, char** argv)
{
    FILE* fp = NULL;
    FILE* fp1 = NULL;
    int fd;
    char rdbuf[50]={0};
    char wrbuf[50]={0};
    fp = fopen(READ_FILE,"r");
    if(NULL == fp)
    {
        perror("OPEN Error:");
        fclose(fp);
        exit(-1);
    }

    fp1 = fopen(WRITE_FILE,"w+");
    if(NULL == fp1)
    {
        perror("OPEN Error:");
        fclose(fp1);
        exit(-1);
    }

    if(12>fread(rdbuf,sizeof(char),sizeof(rdbuf)-1,fp))
    {
        if(ferror(fp))
        {
            perror("read error:");
            fclose(fp);
            exit(-1);
        }
    }
    // printf("%s",rdbuf);

    if(sizeof(rdbuf)>fwrite(rdbuf,1,sizeof(rdbuf),fp1))
    {
        perror("Write Failed");
        fclose(fp1);
        exit(-1);
    }

    fd = fileno(fp1);
    fsync(fd);

    fclose(fp);
    fclose(fp1);
    

    return 0;
}