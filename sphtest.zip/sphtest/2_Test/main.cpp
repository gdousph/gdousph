#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

using namespace std;
#define ERROR -1

int main(int argc, char** argv)
{
    int fd1, fd2;
    unsigned char buf1[4],buf2[4];
    unsigned char readbuf[16];
    int i;
    int ret;
    //创建新文件 设置可读可写 设置在文件末尾写入
    fd1 = open("./testfile", O_RDWR|O_APPEND|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH|S_IWOTH|S_IWGRP);
    if(-1 == fd1)
    {
        perror("fd1 open failed:");
    }

    fd2 = dup2(fd1,100);
    if(-1 == fd2)
    {
        perror("dup failed:");
    }

    buf1[0] = 0x11;
    buf1[1] = 0x22;
    buf1[2] = 0x33;
    buf1[3] = 0x44;

    buf2[0] = 0xAA;
    buf2[1] = 0xBB;
    buf2[2] = 0XCC;
    buf2[3] = 0XDD;

    for(i = 0; i<4; i++)
    {
        ret = write(fd1,buf1,sizeof(buf1));
        if(-1 == ret)
        {
            perror("wirte failed:");
            return ERROR;
        }
        ret = write(fd2,buf2,sizeof(buf2));
        if(-1 == ret)
        {
            perror("write failed:");
            return ERROR;
        }
    }

    ret = lseek(fd1,0,SEEK_SET);
    if(-1 == ret)
    {
        perror("set error:");
    }

    ret = read(fd1,readbuf,sizeof(readbuf));
    if(ret == -1)
    {
        perror("read_error:");
    }
    
    // for(i = 0;i<16;i++)
    // {   
    //     printf("%x",readbuf[i]);
    // }
    printf("fd1:%d,fd2:%d \r\n",fd1,fd2);
    

    //关闭文件描述符
    close(fd1);
    close(fd2);


    return 0;
}