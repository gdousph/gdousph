#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>


using namespace std;

#define MaxLenth 1024
#define MinLenth 0

int main(int argc, char **argv)
{
    int fd1,fd2;
    int ret;
    off_t offt;
    char buffer[100];

    //创建一个新文件
    fd1 = open("./hlllo.txt",O_RDWR, S_IRWXU | S_IRGRP | S_IROTH);
    if(-1 == fd1)
    {
        perror("open failed:");
        return fd1;
    }
    
    ret = ftruncate(fd1,MaxLenth);
    if(-1 == ret)
    {
        perror("truncate failed:");
    }

    // ret = ftruncate(fd1,MinLenth);
    // if(-1 == ret)
    // {
    //     perror("truncate failed:");
    // }
    





    return 0;
}