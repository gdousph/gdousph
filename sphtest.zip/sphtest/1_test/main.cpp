#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>


using namespace std;

#define OFFSET 20
#define OFFSTART 0

int main(int argc, char **argv)
{
    int fd1,fd2;
    off_t offt;
    char buffer[100];

    //打开已有文件，使用只读的方式
    fd1 = open("../hle.txt", O_RDONLY);
    if(-1 == fd1)
    {
        perror("open failed:");
        return fd1;    
    }
    //创建一个新文件
    fd2 = open("./hlllo.txt",O_RDWR | O_CREAT, S_IRWXU | S_IRGRP | S_IROTH);
    if(-1 == fd2)
    {
        perror("open failed:");
        return fd2;
    }
    
    offt = lseek(fd1, OFFSET, SEEK_SET); 
    if(-1 == offt)
    {
        cout<<"offt set failed"<<endl;
    }

    offt = lseek(fd2, OFFSTART, SEEK_SET); 
    if(-1 == offt)
    {
        cout<<"offt set failed"<<endl;
    }
    
    fd1 = read(fd1,buffer, sizeof(buffer));
    if(-1 == fd1)
    {
        cout << "Error reading" <<endl;
        return fd1;
    }

    fd2 = write(fd2,buffer,sizeof(buffer));
    if(-1 == fd2)
    {
        cout<<"Error writing"<<endl;
        return fd2;
    }

    fd1 = close(fd1);
    fd2 = close(fd2);


    return 0;
}